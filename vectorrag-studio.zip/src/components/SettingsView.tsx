import React from 'react';
import {
  Settings,
  Sliders,
  ShieldCheck,
  Cpu,
  Database,
  Lock,
  Layers,
  Sparkles,
  Server,
  Key,
  CheckCircle2,
} from 'lucide-react';
import { RAGSettings } from '../types';
import { useAuth } from '../context/AuthContext';

interface SettingsViewProps {
  settings: RAGSettings;
  setSettings: React.Dispatch<React.SetStateAction<RAGSettings>>;
  documentCount: number;
  chunkCount: number;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  setSettings,
  documentCount,
  chunkCount,
}) => {
  const { user, token } = useAuth();

  return (
    <div className="max-w-5xl mx-auto p-3 sm:p-5 text-[#141414] space-y-4 font-mono">
      {/* Header */}
      <div className="bg-white border border-[#141414] p-4 sm:p-5 shadow-none">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#141414] text-white flex items-center justify-center text-xs font-mono font-bold">
            <Settings className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm font-mono font-bold uppercase tracking-wider text-[#141414]">
              RAG_SYSTEM_CONFIGURATION & HYPERPARAMETERS
            </h1>
            <p className="text-[11px] font-mono text-[#666]">
              Vector database retrieval thresholds, multi-tenancy isolation policies, and inference tuning
            </p>
          </div>
        </div>
      </div>

      {/* RAG Generation Hyperparameters */}
      <div className="bg-white border border-[#141414] p-4 sm:p-5 space-y-4">
        <h3 className="text-xs font-mono font-bold uppercase text-[#141414] flex items-center gap-2 border-b border-[#141414] pb-2.5">
          <Sliders className="w-3.5 h-3.5" />
          RETRIEVAL_&_GENERATION_PARAMETERS
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Top-K */}
          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#141414]">TOP_K_CHUNKS</span>
              <span className="text-xs font-bold text-white bg-[#141414] px-2 py-0.5">
                {settings.topK} CHUNKS
              </span>
            </div>
            <p className="text-[11px] text-[#666]">
              Maximum number of highest-scoring vector partitions injected into Gemini's context window.
            </p>
            <input
              type="range"
              min="1"
              max="10"
              value={settings.topK}
              onChange={e => setSettings(prev => ({ ...prev, topK: Number(e.target.value) }))}
              className="w-full accent-[#141414] cursor-pointer"
            />
          </div>

          {/* Similarity Threshold */}
          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#141414]">MIN_COSINE_SIMILARITY</span>
              <span className="text-xs font-bold text-white bg-[#141414] px-2 py-0.5">
                {Math.round(settings.similarityThreshold * 100)}%
              </span>
            </div>
            <p className="text-[11px] text-[#666]">
              Strict cutoff score for dense embedding cosine distance similarity.
            </p>
            <input
              type="range"
              min="0.1"
              max="0.85"
              step="0.05"
              value={settings.similarityThreshold}
              onChange={e => setSettings(prev => ({ ...prev, similarityThreshold: Number(e.target.value) }))}
              className="w-full accent-[#141414] cursor-pointer"
            />
          </div>

          {/* Temperature */}
          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#141414]">INFERENCE_TEMPERATURE</span>
              <span className="text-xs font-bold text-white bg-[#141414] px-2 py-0.5">
                {settings.temperature}
              </span>
            </div>
            <p className="text-[11px] text-[#666]">
              Low temperature (0.1 - 0.3) enforces strict adherence to grounding context without hallucinatory drift.
            </p>
            <input
              type="range"
              min="0.0"
              max="1.0"
              step="0.1"
              value={settings.temperature}
              onChange={e => setSettings(prev => ({ ...prev, temperature: Number(e.target.value) }))}
              className="w-full accent-[#141414] cursor-pointer"
            />
          </div>

          {/* Strict Grounding Toggle */}
          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-[#141414] block">STRICT_GROUNDING_MODE</span>
                <p className="text-[11px] text-[#666] mt-0.5">
                  Explicitly reject query if vector similarity does not meet threshold.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSettings(prev => ({ ...prev, strictGrounding: !prev.strictGrounding }))}
                className={`w-12 h-6 border border-[#141414] flex items-center p-0.5 transition-colors ${
                  settings.strictGrounding ? 'bg-[#141414]' : 'bg-white'
                }`}
              >
                <div
                  className={`w-4 h-4 transform transition-transform ${
                    settings.strictGrounding ? 'bg-white translate-x-6' : 'bg-[#141414] translate-x-0'
                  }`}
                />
              </button>
            </div>
            <div className="text-[11px] font-bold text-emerald-700 pt-1">
              {settings.strictGrounding ? '● ANTI_HALLUCINATION_GUARD_ACTIVE' : '○ RELAXED_INFERENCE_ALLOWED'}
            </div>
          </div>
        </div>
      </div>

      {/* Security & Authentication Info */}
      <div className="bg-white border border-[#141414] p-4 sm:p-5 space-y-3">
        <h3 className="text-xs font-mono font-bold uppercase text-[#141414] flex items-center gap-2 border-b border-[#141414] pb-2.5">
          <ShieldCheck className="w-3.5 h-3.5" />
          MULTI_TENANCY_ISOLATION & USER_AUTHENTICATION
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-1.5">
            <span className="text-[10px] text-[#666] uppercase block font-bold">AUTHENTICATED_SESSION:</span>
            <div className="text-xs font-bold text-[#141414] uppercase">{user?.name || 'GUEST_DEVELOPER'}</div>
            <div className="text-[11px] text-[#666]">{user?.email || 'dev@ragstudio.ai'}</div>
            <div className="pt-2 text-[10px] text-emerald-700 flex items-center gap-1.5 font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>JWT_BEARER_ACTIVE (SESSION VALID)</span>
            </div>
          </div>

          <div className="bg-[#F8F7F4] p-3.5 border border-[#141414] space-y-1.5">
            <span className="text-[10px] text-[#666] uppercase block font-bold">SECURITY_CONSTRAINTS:</span>
            <ul className="space-y-1 text-[11px] text-[#333]">
              <li className="flex items-start gap-1.5">
                <span className="text-[#141414] font-bold">•</span>
                <span>Vector chunks strictly scoped to authenticated user ID</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-[#141414] font-bold">•</span>
                <span>Passwords salted with Bcrypt work factor 10</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="text-[#141414] font-bold">•</span>
                <span>Gemini API keys securely proxied via server backend</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* RAG Architecture Diagram */}
      <div className="bg-white border border-[#141414] p-4 sm:p-5 space-y-3">
        <h3 className="text-xs font-mono font-bold uppercase text-[#141414] flex items-center gap-2 border-b border-[#141414] pb-2.5">
          <Cpu className="w-3.5 h-3.5" />
          RAG_DATA_PIPELINE_ARCHITECTURE
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-2.5 text-xs">
          <div className="bg-[#F8F7F4] p-3 border border-[#141414] space-y-1">
            <div className="text-[10px] font-bold text-white bg-[#141414] px-1.5 py-0.2 inline-block">
              [STAGE_01]
            </div>
            <div className="font-bold text-[#141414] mt-1">INGEST & CHUNK</div>
            <p className="text-[10px] text-[#666] leading-relaxed">
              Text tokenization, recursive sliding chunk partitions, and metadata tagging.
            </p>
          </div>

          <div className="bg-[#F8F7F4] p-3 border border-[#141414] space-y-1">
            <div className="text-[10px] font-bold text-white bg-[#141414] px-1.5 py-0.2 inline-block">
              [STAGE_02]
            </div>
            <div className="font-bold text-[#141414] mt-1">VECTOR_EMBEDDING</div>
            <p className="text-[10px] text-[#666] leading-relaxed">
              768-dimensional dense vector embeddings generated via Gemini Embedding API.
            </p>
          </div>

          <div className="bg-[#F8F7F4] p-3 border border-[#141414] space-y-1">
            <div className="text-[10px] font-bold text-white bg-[#141414] px-1.5 py-0.2 inline-block">
              [STAGE_03]
            </div>
            <div className="font-bold text-[#141414] mt-1">COSINE_RETRIEVAL</div>
            <p className="text-[10px] text-[#666] leading-relaxed">
              Fast cosine distance similarity search filtered by user tenancy boundaries.
            </p>
          </div>

          <div className="bg-[#F8F7F4] p-3 border border-[#141414] space-y-1">
            <div className="text-[10px] font-bold text-white bg-[#141414] px-1.5 py-0.2 inline-block">
              [STAGE_04]
            </div>
            <div className="font-bold text-[#141414] mt-1">GROUNDED_SYNTHESIS</div>
            <p className="text-[10px] text-[#666] leading-relaxed">
              Gemini model synthesizes factual response with explicit bracketed citations [1], [2].
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

