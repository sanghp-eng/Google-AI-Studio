import React, { useState } from 'react';
import { X, UploadCloud, FileText, Settings2, Sparkles, Check, AlertCircle, Layers } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface DocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const DocumentModal: React.FC<DocumentModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { authHeader } = useAuth();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Chuyên ngành AI');
  const [tagsInput, setTagsInput] = useState('');
  const [content, setContent] = useState('');
  const [chunkingStrategy, setChunkingStrategy] = useState<'paragraph' | 'fixed_window' | 'semantic_sentence'>('paragraph');
  const [chunkSize, setChunkSize] = useState(350);
  const [chunkOverlap, setChunkOverlap] = useState(50);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!title) {
      setTitle(file.name.replace(/\.[^/.]+$/, ''));
    }

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      setContent(text);
    };
    reader.readAsText(file);
  };

  const calculateEstimatedChunks = () => {
    if (!content.trim()) return 0;
    if (chunkingStrategy === 'paragraph') {
      return content.split(/\n\s*\n/).filter(Boolean).length || 1;
    }
    if (chunkingStrategy === 'semantic_sentence') {
      const sentences = content.match(/[^.!?\n]+[.!?\n]+/g) || [content];
      return Math.max(1, Math.ceil(sentences.length / 3));
    }
    return Math.max(1, Math.ceil(content.length / (chunkSize - chunkOverlap)));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      setError('Vui lòng nhập đầy đủ tiêu đề và nội dung tài liệu.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    try {
      const res = await fetch('/api/kb/documents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeader,
        },
        body: JSON.stringify({
          title: title.trim(),
          content: content.trim(),
          category: category.trim(),
          tags,
          chunkingStrategy,
          chunkSize,
          chunkOverlap,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Lỗi khi lưu tài liệu');
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Không thể tạo vector embeddings');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#141414]/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white border border-[#141414] p-5 shadow-2xl text-[#141414] max-h-[90vh] flex flex-col font-mono">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#141414]">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 bg-[#141414] text-white flex items-center justify-center text-xs font-bold">
              <UploadCloud className="w-3.5 h-3.5" />
            </div>
            <div>
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#141414]">
                INGEST_DOCUMENT & EMBEDDING_VECTORIZATION
              </h3>
              <p className="text-[10px] text-[#666]">
                Automatic partition chunking & 768D semantic projection pipeline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#666] hover:text-[#141414] p-1 hover:bg-[#E4E3E0] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="my-2.5 p-2.5 bg-rose-50 border border-rose-600 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto space-y-3 py-3 pr-1">
          {/* File Upload drag area */}
          <div className="border border-dashed border-[#141414] hover:bg-[#F8F7F4] p-3 text-center bg-[#F8F7F4] transition-colors relative">
            <input
              type="file"
              accept=".txt,.md,.json,.csv"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
            />
            <FileText className="w-6 h-6 text-[#141414] mx-auto mb-1" />
            <p className="text-xs font-bold text-[#141414]">
              DRAG & DROP FILE HERE, OR <span className="underline">BROWSE SYSTEM</span> (.txt, .md, .json)
            </p>
            <p className="text-[10px] text-[#666] mt-0.5">Full UTF-8 Vietnamese & English character encodings supported</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-[#141414] uppercase mb-1">DOCUMENT_TITLE *</label>
              <input
                id="doc-title-input"
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Technical_Spec_RAG_2026.md"
                className="w-full bg-[#F8F7F4] border border-[#141414] px-3 py-1.5 text-xs text-[#141414] placeholder-[#888] focus:outline-none focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-[#141414] uppercase mb-1">CATEGORY_TAG</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full bg-[#F8F7F4] border border-[#141414] px-3 py-1.5 text-xs text-[#141414] focus:outline-none focus:bg-white"
              >
                <option value="Chuyên ngành AI">AI & Vector Systems</option>
                <option value="Bảo mật & Pháp lý">Security & Governance</option>
                <option value="Tài liệu Sản phẩm">Product Documentation</option>
                <option value="Chính sách Công ty">Corporate Policies</option>
                <option value="Kỹ thuật & Kiến trúc">System Architecture</option>
                <option value="Khác">Miscellaneous</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-[#141414] uppercase mb-1">METADATA_TAGS (COMMA_SEPARATED)</label>
            <input
              type="text"
              value={tagsInput}
              onChange={e => setTagsInput(e.target.value)}
              placeholder="RAG, VectorDB, Gemini, Embeddings"
              className="w-full bg-[#F8F7F4] border border-[#141414] px-3 py-1.5 text-xs text-[#141414] placeholder-[#888] focus:outline-none focus:bg-white"
            />
          </div>

          {/* Chunking Strategy Configuration */}
          <div className="bg-[#F8F7F4] border border-[#141414] p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase">
                <Settings2 className="w-3.5 h-3.5" />
                CHUNKING_STRATEGY_CONFIG
              </span>
              <span className="text-[9px] px-1.5 py-0.2 bg-[#141414] text-white font-bold">
                ~{calculateEstimatedChunks()} CHUNKS ESTIMATED
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setChunkingStrategy('paragraph')}
                className={`p-2 border text-left text-xs transition-all ${
                  chunkingStrategy === 'paragraph'
                    ? 'border-[#141414] bg-[#141414] text-white'
                    : 'border-[#141414] bg-white text-[#141414] hover:bg-[#E4E3E0]'
                }`}
              >
                <div className="font-bold mb-0.5 text-[11px] uppercase">PARAGRAPH</div>
                <p className={`text-[9px] leading-tight ${chunkingStrategy === 'paragraph' ? 'text-[#CCC]' : 'text-[#666]'}`}>
                  Split on double newline boundaries
                </p>
              </button>

              <button
                type="button"
                onClick={() => setChunkingStrategy('semantic_sentence')}
                className={`p-2 border text-left text-xs transition-all ${
                  chunkingStrategy === 'semantic_sentence'
                    ? 'border-[#141414] bg-[#141414] text-white'
                    : 'border-[#141414] bg-white text-[#141414] hover:bg-[#E4E3E0]'
                }`}
              >
                <div className="font-bold mb-0.5 text-[11px] uppercase">SENTENCE</div>
                <p className={`text-[9px] leading-tight ${chunkingStrategy === 'semantic_sentence' ? 'text-[#CCC]' : 'text-[#666]'}`}>
                  Group intact sentences without truncating
                </p>
              </button>

              <button
                type="button"
                onClick={() => setChunkingStrategy('fixed_window')}
                className={`p-2 border text-left text-xs transition-all ${
                  chunkingStrategy === 'fixed_window'
                    ? 'border-[#141414] bg-[#141414] text-white'
                    : 'border-[#141414] bg-white text-[#141414] hover:bg-[#E4E3E0]'
                }`}
              >
                <div className="font-bold mb-0.5 text-[11px] uppercase">SLIDING_WINDOW</div>
                <p className={`text-[9px] leading-tight ${chunkingStrategy === 'fixed_window' ? 'text-[#CCC]' : 'text-[#666]'}`}>
                  Fixed character bounds with overlap
                </p>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <div className="flex justify-between text-[10px] text-[#666] mb-1">
                  <span>CHUNK_SIZE (CHARS)</span>
                  <span className="font-bold text-[#141414]">{chunkSize}</span>
                </div>
                <input
                  type="range"
                  min="150"
                  max="1200"
                  step="50"
                  value={chunkSize}
                  onChange={e => setChunkSize(Number(e.target.value))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] text-[#666] mb-1">
                  <span>CHUNK_OVERLAP (CHARS)</span>
                  <span className="font-bold text-[#141414]">{chunkOverlap}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  step="10"
                  value={chunkOverlap}
                  onChange={e => setChunkOverlap(Number(e.target.value))}
                  className="w-full accent-[#141414] cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-[10px] font-bold text-[#141414] uppercase">RAW_DOCUMENT_CONTENT *</label>
              <span className="text-[10px] text-[#666] font-mono">{content.length} CHARS</span>
            </div>
            <textarea
              id="doc-content-textarea"
              rows={7}
              required
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Paste raw knowledge documentation, technical guides, system architecture specs, or organizational policies..."
              className="w-full bg-[#F8F7F4] border border-[#141414] p-3 text-xs text-[#141414] placeholder-[#888] font-mono focus:outline-none focus:bg-white leading-relaxed"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="pt-3 border-t border-[#141414] flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 border border-[#141414] bg-white hover:bg-[#E4E3E0] text-[#141414] text-xs font-bold transition-colors uppercase"
          >
            DISCARD
          </button>

          <button
            id="doc-submit-btn"
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitting || !content.trim() || !title.trim()}
            className="px-4 py-1.5 bg-[#141414] hover:bg-[#333] disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center gap-2 uppercase"
          >
            {isSubmitting ? (
              <>
                <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>COMPUTING_EMBEDDINGS...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>INGEST & VECTORIZE</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

